﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MagicSweeper
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        int[,] field;
        int sorokSzama = 10;
        int oszlopokSzama = 10;
        Random r = new Random();
        public MainWindow()
        {
            InitializeComponent();
            StartGame();
        }

        public void StartGame()
        {
           
            field = new int[sorokSzama, oszlopokSzama];
            Field.RowDefinitions.Clear();
            Field.ColumnDefinitions.Clear();
            Field.Children.Clear();

            for (int i = 0; i < 16;)
            {
                int x = r.Next(0, 10);
                int y = r.Next(0, 10);
                if (field[x, y] != 2)
                {
                    field[x, y] = 2;
                    i++;
                }
            }

            for (int i = 0; i < sorokSzama; i++)
            {
                Field.RowDefinitions.Add(new RowDefinition());
            }
            for (int i = 0; i < oszlopokSzama; i++)
            {
                Field.ColumnDefinitions.Add(new ColumnDefinition());
            }
            for (int i = 0; i < sorokSzama; i++)
            {
                for (int j = 0; j < oszlopokSzama; j++)
                {
                    Button uj = new();
                    switch(field[i,j])
                    {
                        case 1:
                            uj.Background = new SolidColorBrush(Colors.DarkGray);
                            break;
                        case 2:
                            uj.Background = new SolidColorBrush(Colors.Black);
                            break;
                    }
                    uj.HorizontalAlignment = HorizontalAlignment.Stretch;
                    uj.VerticalAlignment = VerticalAlignment.Stretch;
                    Grid.SetRow(uj, i);
                    Grid.SetColumn(uj, j);
                    Field.Children.Add(uj);
                }
            }

        }
        private void zonaElhelyezes(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            int sor = Grid.GetRow(b);
            int oszlop = Grid.GetColumn(b);
            switch(field[sor,oszlop])
                {
                    case 1:
                        b.Background = new SolidColorBrush(Colors.DarkGray);
                    break;
                    case 2:
                        b.Background = new SolidColorBrush(Colors.Black);
                    break;
                }
        }

    }
}