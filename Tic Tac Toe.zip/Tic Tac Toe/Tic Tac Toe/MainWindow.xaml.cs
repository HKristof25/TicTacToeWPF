﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tic_Tac_Toe
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[,] board;
        char currentPlayer;
        bool gameEnded;
        int Player1Score = 0;
        int Player2Score = 0;

        public MainWindow()
        {
            InitializeComponent();
            StartGame();
        }

        private void StartGame()
        {
            board = new char[3, 3];
            currentPlayer = 'X';
            gameEnded = false;
            Player1.Text = $"{Player1Score}";
            Player2.Text = $"{Player2Score}";

            for (int i = 0; i < GameField.Children.Count; i++)
            {
                ((Button)GameField.Children[i]).Content = string.Empty;
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    board[i, j] = '-';
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (gameEnded == true)
                return;

            Button b = sender as Button;
            int row = Grid.GetRow(b);
            int col = Grid.GetColumn(b);

            if (board[row, col] == '-')
            {
                board[row, col] = currentPlayer;
                b.Content = currentPlayer.ToString();
                CheckForWinner();
                SwitchPlayer();
            }
        }

        private void CheckForWinner()
        {
            //sorok
            for (int i = 0; i < 3; i++)
            {
                if (board[i, 0] != '-' && board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
                {
                    DeclareWinner(board[i, 0]);
                    return;
                }
            }
            //oszlopok
            for (int j = 0; j < 3; j++)
            {
                if (board[0, j] != '-' && board[0, j] == board[1, j] && board[1, j] == board[2, j])
                {
                    DeclareWinner(board[0, j]);
                    return;
                }
            }

            //átlók
            if (board[0, 0] != '-' && board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2])
            {
                DeclareWinner(board[0, 0]);
                return;
            }

            if (board[0, 2] != '-' && board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
            {
                DeclareWinner(board[0, 2]);
                return;
            }

            //döntetlen
            bool draw = true;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i, j] == '-')
                    {
                        draw = false;
                        break;
                    }
                }
                if (draw == false)
                    break;
            }

            if (draw == true)
            {
                MessageBox.Show("Döntetlen!");
                gameEnded = true;
            }
        }

        private void DeclareWinner(char player)
        {
            MessageBox.Show($"{player} nyert!");
            if (player == 'X')
                Player1Score++;
            else
                Player2Score++;
            gameEnded = true;
        }

        private void SwitchPlayer()
        {
            if (currentPlayer == 'X')
                currentPlayer = 'O';
            else
                currentPlayer = 'X';
        }

        private void NewGameButton_Click(object sender, RoutedEventArgs e)
        {
            StartGame();
        }
    }
}